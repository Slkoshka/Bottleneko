import type { ChatterDto, ChatterSummaryDto, DiscordChatterDto, Protocol, TelegramChatterDto, TwitchChatterDto } from './internal/api/bottleneko.gen.js';
import { type NekoRuntime } from './runtime.js';
export declare class ChatterSummary {
    id: string;
    displayName: string;
    username: string;
    isBot: boolean;
    constructor(chatter: ChatterSummaryDto);
}
export declare abstract class Chatter extends ChatterSummary {
    protocol: Protocol;
    constructor(protocol: Protocol, chatter: ChatterDto);
    static fromDto(chatter: ChatterDto): DiscordChatter | TelegramChatter | TwitchChatter;
}
export declare class DiscordChatter extends Chatter {
    discordId: string;
    discriminator: string | null;
    constructor(chatter: DiscordChatterDto);
}
export declare class TelegramChatter extends Chatter {
    telegramId: string;
    firstName: string;
    lastName: string | null;
    languageCode: string | null;
    hasPremium: boolean;
    addedToAttachmentMenu: boolean;
    constructor(chatter: TelegramChatterDto);
}
export declare class TwitchChatter extends Chatter {
    twitchId: string;
    constructor(chatter: TwitchChatterDto);
}
declare class Chatters {
    #private;
    constructor(runtime: NekoRuntime);
    get(id: ChatterDto['id']): Promise<DiscordChatter | TelegramChatter | TwitchChatter>;
    list(): Promise<(DiscordChatter | TelegramChatter | TwitchChatter)[]>;
}
declare const _default: Chatters;
export default _default;
