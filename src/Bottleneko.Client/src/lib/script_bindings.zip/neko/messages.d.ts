import type { AttachmentDto, ChannelTwitchChatMessageDto, ChatMessageDto, ChatMessageFilter, ChatSummaryDto, ChatterSummaryDto, DiscordChatMessageDto, TelegramChatMessageDto, TwitchChatBadge, WhisperTwitchChatMessageDto } from "./internal/api/bottleneko.gen.js";
import type NekoRpc from "./internal/rpc/index.js";
import { type NekoRuntime } from './runtime.js';
declare const makeListener: (rpc: NekoRpc, callback: (message: ChatMessage) => Promise<void> | void, filter: ChatMessageFilter) => Promise<() => Promise<void>>;
export declare abstract class ChatMessage {
    #private;
    id: string;
    connectionId: string;
    timestamp: string;
    chat: ChatSummaryDto;
    author: ChatterSummaryDto;
    text: string | null;
    attachments: AttachmentDto[];
    isSpecial: boolean;
    isDirect: boolean;
    isMissed: boolean;
    constructor(rpc: NekoRpc, message: ChatMessageDto);
    replyText(text: string): Promise<void>;
    getConnection(): Promise<import("./connections.js").DiscordConnection | import("./connections.js").TelegramConnection | import("./connections.js").TwitchConnection>;
    static fromDto(rpc: NekoRpc, message: ChatMessageDto): DiscordChatMessage | TelegramChatMessage | ChannelTwitchChatMessage | WhisperTwitchChatMessage;
}
export declare class DiscordChatMessage extends ChatMessage {
    discordId: string;
    isPinned: boolean;
    mentions: {
        everyone: boolean;
        channelIds: string[];
        roleIds: string[];
        userIds: string[];
    };
    constructor(rpc: NekoRpc, message: DiscordChatMessageDto);
}
export declare class TelegramChatMessage extends ChatMessage {
    constructor(rpc: NekoRpc, message: TelegramChatMessageDto);
}
export declare abstract class TwitchChatMessage extends ChatMessage {
    twitchId: string;
    constructor(rpc: NekoRpc, message: ChannelTwitchChatMessageDto | WhisperTwitchChatMessageDto);
}
export declare class ChannelTwitchChatMessage extends TwitchChatMessage {
    badges: TwitchChatBadge[];
    color: string;
    cheerBits: number | null;
    channelPointsCustomRewardId: string | null;
    roles: {
        isSubscriber: boolean;
        isModerator: boolean;
        isBroadcaster: boolean;
        isVip: boolean;
        isStaff: boolean;
    };
    constructor(rpc: NekoRpc, message: ChannelTwitchChatMessageDto);
}
export declare class WhisperTwitchChatMessage extends TwitchChatMessage {
    constructor(rpc: NekoRpc, message: WhisperTwitchChatMessageDto);
}
declare class Messages {
    #private;
    constructor(runtime: NekoRuntime);
    get received(): {
        listen: (callback: Parameters<typeof makeListener>[1]) => Promise<() => Promise<void>>;
        filteredBy: (filter: ChatMessageFilter) => {
            listen: (callback: Parameters<typeof makeListener>[1]) => Promise<() => Promise<void>>;
        };
    };
}
declare const _default: Messages;
export default _default;
