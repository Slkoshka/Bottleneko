import type { ConnectionDto, DiscordConnectionDto, ExtendedConnectionStatus, TelegramConnectionDto } from './internal/api/bottleneko.gen.js';
import type NekoRpc from './internal/rpc/index.js';
import { type NekoRuntime } from './runtime.js';
export declare abstract class Connection {
    #private;
    id: string;
    name: string;
    autoStart: boolean;
    status: ExtendedConnectionStatus;
    constructor(rpc: NekoRpc, connection: ConnectionDto);
    sendText(chatId: string, text: string): Promise<void>;
    static fromDto(rpc: NekoRpc, connection: ConnectionDto): DiscordConnection | TelegramConnection | TwitchConnection;
}
export declare class DiscordConnection extends Connection {
    constructor(rpc: NekoRpc, connection: DiscordConnectionDto);
}
export declare class TelegramConnection extends Connection {
    constructor(rpc: NekoRpc, connection: TelegramConnectionDto);
}
export declare class TwitchConnection extends Connection {
    constructor(rpc: NekoRpc, connection: ConnectionDto);
}
declare class Connections {
    #private;
    constructor(runtime: NekoRuntime);
    get(id: ConnectionDto['id']): Promise<DiscordConnection | TelegramConnection | TwitchConnection>;
    list(): Promise<(DiscordConnection | TelegramConnection | TwitchConnection)[]>;
}
declare const _default: Connections;
export default _default;
