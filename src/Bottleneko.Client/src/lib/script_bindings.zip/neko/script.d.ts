export interface Script {
    getId: () => Promise<string>;
    getName: () => Promise<string>;
    stop: () => void;
}
declare const _default: Script;
export default _default;
