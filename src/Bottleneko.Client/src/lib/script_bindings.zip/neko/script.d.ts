import { type NekoRuntime } from './runtime.js';
declare class Script {
    #private;
    constructor(runtime: NekoRuntime);
    getId(): Promise<string>;
    getName(): Promise<string>;
    stop(): void;
}
declare const _default: Script;
export default _default;
