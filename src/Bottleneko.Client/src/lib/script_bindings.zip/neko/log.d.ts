import { type NekoRuntime } from './runtime.js';
declare class Log {
    #private;
    constructor(runtime: NekoRuntime);
    critical(...args: unknown[]): void;
    error(...args: unknown[]): void;
    warning(...args: unknown[]): void;
    info(...args: unknown[]): void;
    verbose(...args: unknown[]): void;
    debug(...args: unknown[]): void;
}
declare const _default: Log;
export default _default;
