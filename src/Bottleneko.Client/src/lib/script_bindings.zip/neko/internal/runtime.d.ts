import NekoRpc from './rpc/index.js';
import type { NekoRuntime } from '../runtime.js';
export declare class internal__NekoRuntimeImpl implements NekoRuntime {
    #private;
    rpc: NekoRpc;
    private constructor();
    static create(): Promise<internal__NekoRuntimeImpl>;
    stop(): void;
}
declare const _default: {
    init(): Promise<internal__NekoRuntimeImpl>;
    get(): internal__NekoRuntimeImpl;
};
export default _default;
