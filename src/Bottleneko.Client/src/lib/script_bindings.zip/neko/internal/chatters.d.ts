import type { ChatterDto, ChatterSummaryDto, DiscordChatterDto, Protocol, TelegramChatterDto, TwitchChatterDto } from './api/bottleneko.gen.js';
import type { Chatter, ChatterSummary, DiscordChatter, TelegramChatter, TwitchChatter } from '../chatters.js';
export declare class internal__ChatterSummaryImpl implements ChatterSummary {
    id: string;
    displayName: string;
    username: string;
    isBot: boolean;
    constructor(chatter: ChatterSummaryDto);
}
export declare abstract class internal__ChatterImpl<T extends Protocol = Protocol> extends internal__ChatterSummaryImpl implements Chatter {
    protocol: T;
    constructor(protocol: T, chatter: ChatterDto);
    static fromDto(chatter: ChatterDto): internal__DiscordChatterImpl | internal__TelegramChatterImpl | internal__TwitchChatterImpl;
}
export declare class internal__DiscordChatterImpl extends internal__ChatterImpl<'Discord'> implements DiscordChatter {
    discordId: string;
    discriminator: string | null;
    constructor(chatter: DiscordChatterDto);
}
export declare class internal__TelegramChatterImpl extends internal__ChatterImpl<'Telegram'> implements TelegramChatter {
    telegramId: string;
    firstName: string;
    lastName: string | null;
    languageCode: string | null;
    hasPremium: boolean;
    addedToAttachmentMenu: boolean;
    constructor(chatter: TelegramChatterDto);
}
export declare class internal__TwitchChatterImpl extends internal__ChatterImpl<'Twitch'> implements TwitchChatter {
    twitchId: string;
    constructor(chatter: TwitchChatterDto);
}
declare const _default: {
    get(id: ChatterDto["id"]): Promise<internal__DiscordChatterImpl | internal__TelegramChatterImpl | internal__TwitchChatterImpl>;
    list(): Promise<(internal__DiscordChatterImpl | internal__TelegramChatterImpl | internal__TwitchChatterImpl)[]>;
};
export default _default;
