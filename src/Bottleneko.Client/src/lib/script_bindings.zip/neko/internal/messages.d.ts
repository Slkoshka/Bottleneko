import { internal__ChatterSummaryImpl } from './chatters.js';
import type { ChannelTwitchChatMessageDto, ChatMessageDto, ChatMessageFilter, DiscordChatMessageDto, Protocol, TelegramChatMessageDto, TwitchChatBadge, WhisperTwitchChatMessageDto } from './api/bottleneko.gen.js';
import type NekoRpc from './rpc/index.js';
import { internal__AttachmentImpl } from './attachments.js';
import type { ChannelTwitchChatMessage, ChatMessage, DiscordChatMessage, TelegramChatMessage, TwitchChatMessage, WhisperTwitchChatMessage } from '../messages.js';
import { internal__ChatSummaryImpl } from './chats.js';
export declare abstract class ChatMessageImpl<T extends Protocol = Protocol> implements ChatMessage {
    #private;
    protocol: T;
    id: string;
    connectionId: string;
    timestamp: string;
    chat: internal__ChatSummaryImpl;
    author: internal__ChatterSummaryImpl;
    text: string | null;
    attachments: internal__AttachmentImpl[];
    isSpecial: boolean;
    isDirect: boolean;
    isMissed: boolean;
    constructor(rpc: NekoRpc, protocol: T, message: ChatMessageDto);
    replyText(text: string): Promise<void>;
    getConnection(): Promise<import("./connections.js").internal__DiscordConnectionImpl | import("./connections.js").internal__TelegramConnectionImpl | import("./connections.js").internal__TwitchConnectionImpl>;
    static fromDto(rpc: NekoRpc, message: ChatMessageDto): DiscordChatMessageImpl | TelegramChatMessageImpl | ChannelTwitchChatMessageImpl | WhisperTwitchChatMessageImpl;
}
export declare class DiscordChatMessageImpl extends ChatMessageImpl<'Discord'> implements DiscordChatMessage {
    discordId: string;
    isPinned: boolean;
    mentions: {
        everyone: boolean;
        channelIds: string[];
        roleIds: string[];
        userIds: string[];
    };
    constructor(rpc: NekoRpc, message: DiscordChatMessageDto);
}
export declare class TelegramChatMessageImpl extends ChatMessageImpl<'Telegram'> implements TelegramChatMessage {
    constructor(rpc: NekoRpc, message: TelegramChatMessageDto);
}
export declare abstract class TwitchChatMessageImpl<T extends boolean = boolean> extends ChatMessageImpl<'Twitch'> implements TwitchChatMessage {
    twitchId: string;
    isWhisper: T;
    constructor(rpc: NekoRpc, isWhisper: T, message: ChannelTwitchChatMessageDto | WhisperTwitchChatMessageDto);
}
export declare class ChannelTwitchChatMessageImpl extends TwitchChatMessageImpl<false> implements ChannelTwitchChatMessage {
    badges: TwitchChatBadge[];
    color: string;
    cheerBits: number | null;
    channelPointsCustomRewardId: string | null;
    roles: {
        isSubscriber: boolean;
        isModerator: boolean;
        isBroadcaster: boolean;
        isVip: boolean;
        isStaff: boolean;
    };
    constructor(rpc: NekoRpc, message: ChannelTwitchChatMessageDto);
}
export declare class WhisperTwitchChatMessageImpl extends TwitchChatMessageImpl<true> implements WhisperTwitchChatMessage {
    constructor(rpc: NekoRpc, message: WhisperTwitchChatMessageDto);
}
declare const _default: {
    readonly received: {
        listen: (callback: (message: ChatMessageImpl) => Promise<void>) => Promise<() => Promise<void>>;
        filteredBy: (filter: ChatMessageFilter) => {
            listen: (callback: (message: ChatMessageImpl) => Promise<void>) => Promise<() => Promise<void>>;
        };
    };
};
export default _default;
