export interface ActivityStatsDto {
    items: ActivityStatsItemDto[];
}
export interface ActivityStatsItemDto {
    messagesPerMinute: number;
    period: string;
    totalMessages: number;
}
export type AttachmentDto = DiscordAttachmentDto | TelegramAttachmentDto | TwitchAttachmentDto;
export interface ChannelTwitchChatMessageDto {
    $type: 'Twitch.Channel';
    attachments: AttachmentDto[];
    author: ChatterSummaryDto;
    badges: TwitchChatBadge[];
    channelPointsCustomRewardId: string | null;
    chat: ChatSummaryDto;
    cheerBits: number | null;
    color: string;
    connectionId: string;
    customAuthorName: string | null;
    id: string;
    isBroadcaster: boolean;
    isDirect: boolean;
    isMissed: boolean;
    isModerator: boolean;
    isSpecial: boolean;
    isStaff: boolean;
    isSubscriber: boolean;
    isVip: boolean;
    textContent: string | null;
    timestamp: string;
    twitchId: string;
}
export type ChatDto = DiscordChatDto | TelegramChatDto | TwitchChatDto;
export type ChatMessageDto = ChannelTwitchChatMessageDto | DiscordChatMessageDto | TelegramChatMessageDto | WhisperTwitchChatMessageDto;
export interface ChatSummaryDto {
    displayName: string;
    id: string;
}
export type ChatterDto = DiscordChatterDto | TelegramChatterDto | TwitchChatterDto;
export interface ChatterSummaryDto {
    displayName: string;
    id: string;
    isBot: boolean;
    username: string;
}
export type ConnectionDto = DiscordConnectionDto | TelegramConnectionDto | TwitchConnectionDto;
export type ConnectionStatus = 'Connected' | 'Connecting' | 'DelayedReconnect' | 'Error' | 'NotConnected' | 'Reconnecting' | 'Stopping';
export declare const ConnectionStatusValues: ConnectionStatus[];
export interface DiscordAttachmentDto {
    $type: 'Discord';
    contentType: string;
    description: string | null;
    discordId: string;
    id: string;
    name: string | null;
    proxyUrl: string;
    title: string | null;
    url: string;
}
export interface DiscordChannel {
    discordId: string;
    name: string;
    type: DiscordChannelType;
}
export type DiscordChannelType = 'Category' | 'DM' | 'Forum' | 'Group' | 'GuildDirectory' | 'Media' | 'News' | 'NewsThread' | 'PrivateThread' | 'PublicThread' | 'Stage' | 'Store' | 'Text' | 'Voice';
export declare const DiscordChannelTypeValues: DiscordChannelType[];
export interface DiscordChatDto {
    $type: 'Discord';
    channel: DiscordChannel;
    connectionId: string;
    displayName: string;
    guild: DiscordGuild | null;
    id: string;
    isPrivate: boolean;
}
export interface DiscordChatMessageDto {
    $type: 'Discord';
    attachments: AttachmentDto[];
    author: ChatterSummaryDto;
    channelMentions: string[];
    chat: ChatSummaryDto;
    connectionId: string;
    customAuthorName: string | null;
    discordId: string;
    id: string;
    isDirect: boolean;
    isEveryoneMentioned: boolean;
    isMissed: boolean;
    isPinned: boolean;
    isSpecial: boolean;
    roleMentions: string[];
    textContent: string | null;
    timestamp: string;
    userMentions: string[];
}
export interface DiscordChatterDto {
    $type: 'Discord';
    discordId: string;
    discriminator: string | null;
    displayName: string;
    id: string;
    isBot: boolean;
    username: string;
}
export interface DiscordConnectionDto {
    $type: 'Discord';
    autoStart: boolean;
    config: ProtocolConfiguration;
    extendedStatus: ExtendedConnectionStatus;
    id: string;
    name: string;
    protocol: Protocol;
}
export interface DiscordGuild {
    description: string | null;
    discordId: string;
    name: string;
    ownerId: string;
}
export interface EnvironmentInfoDto {
    neko: NekoInfoDto;
    system: SystemInfoDto;
}
export interface ExtendedConnectionStatus {
    status: ConnectionStatus;
    statusChangeDelay: number;
}
export interface JsScriptCode {
    $type: 'JavaScript';
    source: string;
}
export interface NekoInfoDto {
    uptime: number;
    version: string;
}
export type Protocol = 'Discord' | 'Telegram' | 'Twitch';
export declare const ProtocolValues: Protocol[];
export interface ProxyDto {
    hostname: string;
    id: string;
    isAuthRequired: boolean;
    name: string;
    password: string | null;
    port: number;
    type: ProxyType;
    username: string | null;
}
export type ProxyType = 'Http' | 'Https' | 'Socks4' | 'Socks4a' | 'Socks5';
export declare const ProxyTypeValues: ProxyType[];
export type ScriptCode = JsScriptCode;
export interface ScriptDto {
    autoStart: boolean;
    code: ScriptCode;
    description: string;
    id: string;
    name: string;
    status: ScriptStatus;
}
export type ScriptStatus = 'Error' | 'Restarting' | 'Running' | 'Starting' | 'Stopped' | 'Stopping';
export declare const ScriptStatusValues: ScriptStatus[];
export interface SystemInfoDto {
    arch: string;
    currentTime: string;
    dotNetVersion: string;
    hostname: string;
    operatingSystem: string;
    uptime: number;
}
export interface TelegramAttachmentDto {
    $type: 'Telegram';
    contentType: string;
    id: string;
    name: string | null;
}
export interface TelegramChatDto {
    $type: 'Telegram';
    connectionId: string;
    displayName: string;
    firstName: string | null;
    id: string;
    isForum: boolean;
    isPrivate: boolean;
    lastName: string | null;
    telegramId: string;
    title: string | null;
    type: TelegramChatType;
}
export interface TelegramChatMessageDto {
    $type: 'Telegram';
    attachments: AttachmentDto[];
    author: ChatterSummaryDto;
    chat: ChatSummaryDto;
    connectionId: string;
    customAuthorName: string | null;
    id: string;
    isDirect: boolean;
    isMissed: boolean;
    isSpecial: boolean;
    textContent: string | null;
    timestamp: string;
}
export interface TelegramChatterDto {
    $type: 'Telegram';
    addedToAttachmentMenu: boolean;
    displayName: string;
    firstName: string;
    hasPremium: boolean;
    id: string;
    isBot: boolean;
    languageCode: string | null;
    lastName: string | null;
    telegramId: string;
    username: string;
}
export type TelegramChatType = 'Channel' | 'Group' | 'Private' | 'Sender' | 'Supergroup';
export declare const TelegramChatTypeValues: TelegramChatType[];
export interface TelegramConnectionDto {
    $type: 'Telegram';
    autoStart: boolean;
    config: ProtocolConfiguration;
    extendedStatus: ExtendedConnectionStatus;
    id: string;
    name: string;
    protocol: Protocol;
}
export interface TwitchAttachmentDto {
    $type: 'Twitch';
    contentType: string;
    id: string;
    name: string | null;
}
export interface TwitchChatBadge {
    info: string;
    setId: string;
    twitchId: string;
}
export interface TwitchChatDto {
    $type: 'Twitch';
    connectionId: string;
    displayName: string;
    id: string;
    isPrivate: boolean;
    isWhisper: boolean;
    name: string;
    twitchId: string;
}
export interface TwitchChatterDto {
    $type: 'Twitch';
    displayName: string;
    id: string;
    isBot: boolean;
    twitchId: string;
    username: string;
}
export interface TwitchConnectionDto {
    $type: 'Twitch';
    autoStart: boolean;
    config: ProtocolConfiguration;
    extendedStatus: ExtendedConnectionStatus;
    id: string;
    name: string;
    protocol: Protocol;
}
export interface UserDto {
    displayName: string;
    id: string;
    login: string;
}
export interface WhisperTwitchChatMessageDto {
    $type: 'Twitch.Whisper';
    attachments: AttachmentDto[];
    author: ChatterSummaryDto;
    chat: ChatSummaryDto;
    connectionId: string;
    customAuthorName: string | null;
    id: string;
    isDirect: boolean;
    isMissed: boolean;
    isSpecial: boolean;
    textContent: string | null;
    timestamp: string;
    twitchId: string;
}
export interface DiscordProtocolConfiguration {
    $type: 'Discord';
    isMessageContentIntentEnabled: boolean;
    isPresenceIntentEnabled: boolean;
    isServerMembersIntentEnabled: boolean;
    proxyId: string | null;
    receiveEvents: boolean;
    token: string;
}
export type ProtocolConfiguration = DiscordProtocolConfiguration | TelegramProtocolConfiguration | TwitchProtocolConfiguration;
export interface TelegramProtocolConfiguration {
    $type: 'Telegram';
    proxyId: string | null;
    receiveEvents: boolean;
    token: string;
}
export interface TwitchAuth {
    accessToken: string;
    clientId: string;
    me: string;
    refreshToken: string;
    scopes: TwitchScope[];
}
export interface TwitchProtocolChannel {
    eventSubscriptions: TwitchSubscriptionTopic[];
    name: string;
}
export interface TwitchProtocolConfiguration {
    $type: 'Twitch';
    auth: TwitchAuth;
    channels: TwitchProtocolChannel[];
    proxyId: string | null;
    receiveEvents: boolean;
}
export type TwitchScope = 'AnalyticsReadExtensions' | 'AnalyticsReadGames' | 'BitsRead' | 'ChannelBot' | 'ChannelEditCommercial' | 'ChannelManageAds' | 'ChannelManageBroadcast' | 'ChannelManageExtensions' | 'ChannelManageGuestStar' | 'ChannelManageModerators' | 'ChannelManagePolls' | 'ChannelManagePredictions' | 'ChannelManageRaids' | 'ChannelManageRedemptions' | 'ChannelManageSchedule' | 'ChannelManageVideos' | 'ChannelManageVips' | 'ChannelModerate' | 'ChannelReadAds' | 'ChannelReadCharity' | 'ChannelReadEditors' | 'ChannelReadGoals' | 'ChannelReadGuestStar' | 'ChannelReadHypeTrain' | 'ChannelReadPolls' | 'ChannelReadPredictions' | 'ChannelReadRedemptions' | 'ChannelReadStreamKey' | 'ChannelReadSubscriptions' | 'ChannelReadVips' | 'ClipsEdit' | 'ModerationRead' | 'ModeratorManageAnnouncements' | 'ModeratorManageAutomod' | 'ModeratorManageAutomodSettings' | 'ModeratorManageBannedUsers' | 'ModeratorManageBlockedTerms' | 'ModeratorManageChatMessages' | 'ModeratorManageChatSettings' | 'ModeratorManageGuestStar' | 'ModeratorManageShieldMode' | 'ModeratorManageShoutouts' | 'ModeratorManageUnbanRequests' | 'ModeratorManageWarnings' | 'ModeratorReadAutomodSettings' | 'ModeratorReadBannedUsers' | 'ModeratorReadBlockedTerms' | 'ModeratorReadChatMessages' | 'ModeratorReadChatSettings' | 'ModeratorReadChatters' | 'ModeratorReadFollowers' | 'ModeratorReadGuestStar' | 'ModeratorReadModerators' | 'ModeratorReadShieldMode' | 'ModeratorReadShoutouts' | 'ModeratorReadSuspiciousUsers' | 'ModeratorReadUnbanRequests' | 'ModeratorReadVips' | 'ModeratorReadWarnings' | 'UserBot' | 'UserEdit' | 'UserEditBroadcast' | 'UserManageBlockedUsers' | 'UserManageChatColor' | 'UserManageWhispers' | 'UserReadBlockedUsers' | 'UserReadBroadcast' | 'UserReadChat' | 'UserReadEmail' | 'UserReadEmotes' | 'UserReadFollows' | 'UserReadModeratedChannels' | 'UserReadSubscriptions' | 'UserReadWhispers' | 'UserWriteChat';
export declare const TwitchScopeValues: TwitchScope[];
export type TwitchSubscriptionTopic = 'ChannelAdBreakBegin' | 'ChannelBan' | 'ChannelChannelPointsCustomRewardAdd' | 'ChannelChannelPointsCustomRewardRedemptionAdd' | 'ChannelChannelPointsCustomRewardRedemptionUpdate' | 'ChannelChannelPointsCustomRewardRemove' | 'ChannelChannelPointsCustomRewardUpdate' | 'ChannelCharityCampaignDonate' | 'ChannelCharityCampaignProgress' | 'ChannelCharityCampaignStart' | 'ChannelCharityCampaignStop' | 'ChannelChatMessage' | 'ChannelCheer' | 'ChannelFollow' | 'ChannelGoalBegin' | 'ChannelGoalEnd' | 'ChannelGoalProgress' | 'ChannelHypeTrainBegin' | 'ChannelHypeTrainEnd' | 'ChannelHypeTrainProgress' | 'ChannelModeratorAdd' | 'ChannelModeratorRemove' | 'ChannelPollBegin' | 'ChannelPollEnd' | 'ChannelPollProgress' | 'ChannelPredictionBegin' | 'ChannelPredictionEnd' | 'ChannelPredictionLock' | 'ChannelPredictionProgress' | 'ChannelRaidFrom' | 'ChannelRaidTo' | 'ChannelShieldModeBegin' | 'ChannelShieldModeEnd' | 'ChannelShoutoutCreate' | 'ChannelShoutoutReceive' | 'ChannelSubscribe' | 'ChannelSubscriptionEnd' | 'ChannelSubscriptionGift' | 'ChannelSubscriptionMessage' | 'ChannelSuspiciousUserMessage' | 'ChannelSuspiciousUserUpdate' | 'ChannelUnban' | 'ChannelUpdate' | 'ChannelVipAdd' | 'ChannelVipRemove' | 'ChannelWarningAcknowledge' | 'ChannelWarningSend' | 'StreamOffline' | 'StreamOnline' | 'UserUpdate' | 'UserWhisperMessage';
export declare const TwitchSubscriptionTopicValues: TwitchSubscriptionTopic[];
export interface AuthenticatePacket {
    $type: 'Authenticate';
    accessToken: string;
    clientType: ClientType;
}
export interface ChatMessageFilter {
    connectionId: string | null;
    protocol: Protocol | null;
}
export interface ChatMessageLetter {
    $type: 'ChatMessage';
    content: ChatMessageDto;
}
export type ClientType = 'Api' | 'Script';
export declare const ClientTypeValues: ClientType[];
export type ErrorCode = 'ConnectionError' | 'DuplicateName' | 'Forbidden' | 'InternalError' | 'InvalidOperation' | 'InvalidValue' | 'NotFound' | 'SetupRequired' | 'Timeout' | 'Unauthorized' | 'Unsupported';
export declare const ErrorCodeValues: ErrorCode[];
export interface ErrorResult {
    $type: 'Error';
    code: ErrorCode;
    extra: object | null;
    message: string;
}
export type Letter = ChatMessageLetter | LogLetter;
export interface LogFilter {
    category: string | null;
    severities: LogSeverity[] | null;
    sourceId: string | null;
    sourceType: LogSourceType | null;
}
export interface LogLetter {
    $type: 'Log';
    category: string;
    id: string;
    severity: LogSeverity;
    sourceId: string;
    sourceType: LogSourceType;
    text: string;
    timestamp: string;
}
export interface MailPacket {
    $type: 'Mail';
    letters: Letter[];
    subscriptionId: SubscriptionId;
}
export type Packet = AuthenticatePacket | MailPacket | RequestPacket | ResponsePacket;
export interface RequestPacket {
    $type: 'Request';
    request: RpcRequest;
    requestId: string;
}
export interface ResponsePacket {
    $type: 'Response';
    requestId: string;
    result: ResponseResult;
}
export type ResponseResult = ErrorResult | SuccessResult;
export type RpcCallerRole = 'Anonymous' | 'Script' | 'User';
export declare const RpcCallerRoleValues: RpcCallerRole[];
export type RpcRequest = ChattersGetRequest | ChattersListRequest | ConnectionsAddRequest | ConnectionsDeleteRequest | ConnectionsGetAttachmentUrlRequest | ConnectionsGetRequest | ConnectionsListRequest | ConnectionsRestartRequest | ConnectionsStartRequest | ConnectionsStopRequest | ConnectionsTestRequest | ConnectionsUpdateRequest | LoggingLogRequest | LoggingSubscribeRequest | LoggingUnsubscribeRequest | MessagesSendTextRequest | MessagesSubscribeRequest | MessagesUnsubscribeRequest | ScriptGetIdRequest | ScriptGetNameRequest;
export type RpcResponse = ChattersGetResponse | ChattersListResponse | ConnectionsAddResponse | ConnectionsDeleteResponse | ConnectionsGetAttachmentUrlResponse | ConnectionsGetResponse | ConnectionsListResponse | ConnectionsRestartResponse | ConnectionsStartResponse | ConnectionsStopResponse | ConnectionsTestResponse | ConnectionsUpdateResponse | LoggingLogResponse | LoggingSubscribeResponse | LoggingUnsubscribeResponse | MessagesSendTextResponse | MessagesSubscribeResponse | MessagesUnsubscribeResponse | ScriptGetIdResponse | ScriptGetNameResponse;
export type RpcService = 'Chatters' | 'Connections' | 'Logging' | 'Messages' | 'Script';
export declare const RpcServiceValues: RpcService[];
export interface ChattersGetRequest {
    $type: 'Chatters/Get';
    id: string;
}
export interface ChattersGetResponse {
    $type: 'Chatters/Get';
    result: ChatterDto;
}
export interface ChattersListRequest {
    $type: 'Chatters/List';
}
export interface ChattersListResponse {
    $type: 'Chatters/List';
    result: ChatterDto[];
}
export interface ConnectionsAddRequest {
    $type: 'Connections/Add';
    config: ProtocolConfiguration;
    name: string;
    protocol: Protocol;
}
export interface ConnectionsAddResponse {
    $type: 'Connections/Add';
    result: ConnectionDto;
}
export interface ConnectionsDeleteRequest {
    $type: 'Connections/Delete';
    id: string;
}
export interface ConnectionsDeleteResponse {
    $type: 'Connections/Delete';
}
export interface ConnectionsGetAttachmentUrlRequest {
    $type: 'Connections/GetAttachmentUrl';
    attachmentId: string;
    id: string;
}
export interface ConnectionsGetAttachmentUrlResponse {
    $type: 'Connections/GetAttachmentUrl';
    result: string;
}
export interface ConnectionsGetRequest {
    $type: 'Connections/Get';
    id: string;
}
export interface ConnectionsGetResponse {
    $type: 'Connections/Get';
    result: ConnectionDto;
}
export interface ConnectionsListRequest {
    $type: 'Connections/List';
}
export interface ConnectionsListResponse {
    $type: 'Connections/List';
    result: ConnectionDto[];
}
export interface ConnectionsRestartRequest {
    $type: 'Connections/Restart';
    id: string;
}
export interface ConnectionsRestartResponse {
    $type: 'Connections/Restart';
}
export interface ConnectionsStartRequest {
    $type: 'Connections/Start';
    id: string;
}
export interface ConnectionsStartResponse {
    $type: 'Connections/Start';
}
export interface ConnectionsStopRequest {
    $type: 'Connections/Stop';
    id: string;
}
export interface ConnectionsStopResponse {
    $type: 'Connections/Stop';
}
export interface ConnectionsTestRequest {
    $type: 'Connections/Test';
    config: ProtocolConfiguration;
    protocol: Protocol;
}
export interface ConnectionsTestResponse {
    $type: 'Connections/Test';
    result: ConnectionTestResult;
}
export interface ConnectionsUpdateRequest {
    $type: 'Connections/Update';
    autoStart: boolean | null;
    config: ProtocolConfiguration | null;
    id: string;
    name: string | null;
}
export interface ConnectionsUpdateResponse {
    $type: 'Connections/Update';
    result: ConnectionDto;
}
export interface ConnectionTestResult {
    duration: number;
    extra: object | null;
}
export interface LoggingLogRequest {
    $type: 'Logging/Log';
    message: string;
    severity: LogSeverity;
}
export interface LoggingLogResponse {
    $type: 'Logging/Log';
}
export interface LoggingSubscribeRequest {
    $type: 'Logging/Subscribe';
    filter: LogFilter;
}
export interface LoggingSubscribeResponse {
    $type: 'Logging/Subscribe';
    result: SubscriptionId;
}
export interface LoggingUnsubscribeRequest {
    $type: 'Logging/Unsubscribe';
    subscriptionId: SubscriptionId;
}
export interface LoggingUnsubscribeResponse {
    $type: 'Logging/Unsubscribe';
}
export interface MessagesSendTextRequest {
    $type: 'Messages/SendText';
    chatId: string;
    connectionId: string;
    replyToMessageId: string | null;
    text: string;
}
export interface MessagesSendTextResponse {
    $type: 'Messages/SendText';
}
export interface MessagesSubscribeRequest {
    $type: 'Messages/Subscribe';
    filter: ChatMessageFilter;
}
export interface MessagesSubscribeResponse {
    $type: 'Messages/Subscribe';
    result: SubscriptionId;
}
export interface MessagesUnsubscribeRequest {
    $type: 'Messages/Unsubscribe';
    subscriptionId: SubscriptionId;
}
export interface MessagesUnsubscribeResponse {
    $type: 'Messages/Unsubscribe';
}
export interface ScriptGetIdRequest {
    $type: 'Script/GetId';
}
export interface ScriptGetIdResponse {
    $type: 'Script/GetId';
    result: string;
}
export interface ScriptGetNameRequest {
    $type: 'Script/GetName';
}
export interface ScriptGetNameResponse {
    $type: 'Script/GetName';
    result: string;
}
export interface SubscriptionId {
    id: string;
}
export interface SuccessResult {
    $type: 'Success';
    data: RpcResponse;
}
export type LogSeverity = 'Critical' | 'Debug' | 'Error' | 'Info' | 'Verbose' | 'Warning';
export declare const LogSeverityValues: LogSeverity[];
export type LogSourceType = 'Connection' | 'Script' | 'System';
export declare const LogSourceTypeValues: LogSourceType[];
