import type { Packet, RpcRequest, RpcResponse } from '../api/bottleneko.gen.js';
import AbstractRpc, { type ResultType } from '../api/rpc.gen.js';
export declare const MAX_SAFE_PACKET_SIZE: number;
export type TransportType = 'unix' | 'unixabstract' | 'namedpipes';
export default class NekoRpc extends AbstractRpc {
    #private;
    private constructor();
    call<T extends RpcResponse>(request: RpcRequest): Promise<ResultType<T, void>>;
    send(data: Packet): Promise<void>;
    static create(transportType: TransportType, name: string, onConnectionClosed: () => void): Promise<{
        rpc: NekoRpc;
        destroy: () => void;
    }>;
}
