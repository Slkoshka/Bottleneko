declare const _default: {
    getId(): Promise<string>;
    getName(): Promise<string>;
    stop(): void;
};
export default _default;
