import type { ChatSummary } from "../chats.js";
import type { ChatSummaryDto } from './api/bottleneko.gen.js';
export declare class internal__ChatSummaryImpl implements ChatSummary {
    id: string;
    displayName: string;
    constructor(chat: ChatSummaryDto);
}
