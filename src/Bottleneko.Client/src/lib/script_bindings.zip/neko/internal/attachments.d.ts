import type { AttachmentDto, DiscordAttachmentDto, Protocol, TelegramAttachmentDto, TwitchAttachmentDto } from './api/bottleneko.gen.js';
export declare abstract class internal__AttachmentImpl<T extends Protocol = Protocol> {
    protocol: Protocol;
    id: string;
    name: string | null;
    contentType: string;
    constructor(protocol: T, attachment: AttachmentDto);
    static fromDto(attachment: AttachmentDto): internal__DiscordAttachmentImpl | internal__TelegramAttachmentImpl | internal__TwitchAttachmentImpl;
}
export declare class internal__DiscordAttachmentImpl extends internal__AttachmentImpl<'Discord'> {
    discordId: string;
    description: string | null;
    title: string | null;
    url: string;
    proxyUrl: string;
    constructor(attachment: DiscordAttachmentDto);
}
export declare class internal__TelegramAttachmentImpl extends internal__AttachmentImpl<'Telegram'> {
    constructor(attachment: TelegramAttachmentDto);
}
export declare class internal__TwitchAttachmentImpl extends internal__AttachmentImpl<'Twitch'> {
    constructor(attachment: TwitchAttachmentDto);
}
