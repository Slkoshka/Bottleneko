import type { ConnectionDto, DiscordConnectionDto, ExtendedConnectionStatus, Protocol, TelegramConnectionDto } from './api/bottleneko.gen.js';
import type { Connection, DiscordConnection, TelegramConnection, TwitchConnection } from '../connections.js';
export declare abstract class internal__ConnectionImpl<T extends Protocol = Protocol> implements Connection {
    protocol: T;
    id: string;
    name: string;
    autoStart: boolean;
    status: ExtendedConnectionStatus;
    constructor(protocol: T, connection: ConnectionDto);
    sendText(chatId: string, text: string): Promise<void>;
    static fromDto(connection: ConnectionDto): internal__DiscordConnectionImpl | internal__TelegramConnectionImpl | internal__TwitchConnectionImpl;
}
export declare class internal__DiscordConnectionImpl extends internal__ConnectionImpl<'Discord'> implements DiscordConnection {
    constructor(connection: DiscordConnectionDto);
}
export declare class internal__TelegramConnectionImpl extends internal__ConnectionImpl<'Telegram'> implements TelegramConnection {
    constructor(connection: TelegramConnectionDto);
}
export declare class internal__TwitchConnectionImpl extends internal__ConnectionImpl<'Twitch'> implements TwitchConnection {
    constructor(connection: ConnectionDto);
}
declare const _default: {
    get(id: ConnectionDto["id"]): Promise<internal__DiscordConnectionImpl | internal__TelegramConnectionImpl | internal__TwitchConnectionImpl>;
    list(): Promise<(internal__DiscordConnectionImpl | internal__TelegramConnectionImpl | internal__TwitchConnectionImpl)[]>;
};
export default _default;
