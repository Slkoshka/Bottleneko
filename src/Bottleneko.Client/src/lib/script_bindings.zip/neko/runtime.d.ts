export interface NekoRuntime {
    stop: () => void;
}
export interface Runtime {
    init: () => Promise<NekoRuntime>;
    get: () => NekoRuntime;
}
declare const _default: Runtime;
export default _default;
