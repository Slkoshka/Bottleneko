import NekoRpc from './internal/rpc/index.js';
declare class NekoRuntimeImpl {
    #private;
    rpc: NekoRpc;
    private constructor();
    static create(): Promise<NekoRuntimeImpl>;
    stop(): void;
}
declare const _default: NekoRuntimeImpl;
export default _default;
type ExtractTypeFromPromise<Type> = Type extends Promise<infer X> ? X : never;
export type NekoRuntime = ExtractTypeFromPromise<ReturnType<typeof NekoRuntimeImpl.create>>;
