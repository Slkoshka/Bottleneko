import type { ChatMessageDto, ChatMessageFilter } from "./internal/api/bottleneko.gen.js";
import type NekoRpc from "./internal/rpc/index.js";
import { type NekoRuntime } from './runtime.js';
declare const makeListener: (rpc: NekoRpc, callback: (message: ChatMessageDto) => Promise<void> | void, filter: ChatMessageFilter) => Promise<() => Promise<void>>;
declare class Messages {
    #private;
    constructor(runtime: NekoRuntime);
    get received(): {
        listen: (callback: Parameters<typeof makeListener>[1]) => Promise<() => Promise<void>>;
        filteredBy: (filter: ChatMessageFilter) => {
            listen: (callback: Parameters<typeof makeListener>[1]) => Promise<() => Promise<void>>;
        };
    };
}
declare const _default: Messages;
export default _default;
