import type { ConnectionDto } from "./internal/api/bottleneko.gen.js";
import { type NekoRuntime } from './runtime.js';
declare class Connections {
    #private;
    constructor(runtime: NekoRuntime);
    get(id: ConnectionDto['id']): Promise<ConnectionDto>;
    list(): Promise<ConnectionDto[]>;
}
declare const _default: Connections;
export default _default;
