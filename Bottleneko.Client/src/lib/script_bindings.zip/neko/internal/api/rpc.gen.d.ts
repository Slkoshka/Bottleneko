import type * as bottleneko from './bottleneko.gen.js';
export type ResultType<T, Default> = 'result' extends keyof T ? T['result'] : Default;
export default abstract class AbstractRpc {
    script: {
        getId(args: Omit<bottleneko.GetIdRequest, "$type">): Promise<string>;
        doSomething(args: Omit<bottleneko.DoSomethingRequest, "$type">): Promise<void>;
        doSomethingA(args: Omit<bottleneko.DoSomethingARequest, "$type">): Promise<void>;
        getName(args: Omit<bottleneko.GetNameRequest, "$type">): Promise<string>;
        doCrimes(args: Omit<bottleneko.DoCrimesRequest, "$type">): Promise<string>;
    };
    constructor();
    abstract call<T extends bottleneko.RpcResponse>(request: bottleneko.RpcRequest): Promise<ResultType<T, void>>;
}
