import type * as bottleneko from './bottleneko.gen.js';
export type ResultType<T, Default> = 'result' extends keyof T ? T['result'] : Default;
export default abstract class AbstractRpc {
    #private;
    logging: {
        log(args: Omit<bottleneko.LoggingLogRequest, "$type">): Promise<void>;
        subscribe(args: Omit<bottleneko.LoggingSubscribeRequest, "$type">): Promise<bottleneko.SubscriptionId>;
        unsubscribe(args: Omit<bottleneko.LoggingUnsubscribeRequest, "$type">): Promise<void>;
    };
    messages: {
        subscribe(args: Omit<bottleneko.MessagesSubscribeRequest, "$type">): Promise<bottleneko.SubscriptionId>;
        unsubscribe(args: Omit<bottleneko.MessagesUnsubscribeRequest, "$type">): Promise<void>;
    };
    script: {
        getId(args: Omit<bottleneko.ScriptGetIdRequest, "$type">): Promise<string>;
        getName(args: Omit<bottleneko.ScriptGetNameRequest, "$type">): Promise<string>;
    };
    constructor();
    abstract call<T extends bottleneko.RpcResponse>(request: bottleneko.RpcRequest): Promise<ResultType<T, void>>;
    protected onMail(mail: bottleneko.MailPacket): Promise<void>;
    watch<T extends unknown[]>(args: T, subscribe: (...args: T) => Promise<bottleneko.SubscriptionId>, unsubscribe: (args: {
        subscriptionId: bottleneko.SubscriptionId;
    }) => Promise<void>, callback: (letter: bottleneko.Letter) => Promise<void> | void): Promise<() => Promise<void>>;
}
