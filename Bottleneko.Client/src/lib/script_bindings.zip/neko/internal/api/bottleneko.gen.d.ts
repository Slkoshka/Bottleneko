export type RpcCallerRole = 'Script' | 'User' | 'Anonymous';
export declare const RpcCallerRoleValues: RpcCallerRole[];
export type ErrorCode = 'Unauthorized' | 'Forbidden' | 'NotFound' | 'InternalError' | 'DuplicateName' | 'InvalidValue' | 'SetupRequired' | 'Unsupported' | 'InvalidOperation' | 'Timeout' | 'ConnectionError';
export declare const ErrorCodeValues: ErrorCode[];
export type Packet = AuthenticatePacket | MailPacket | RequestPacket | ResponsePacket;
export type ClientType = 'Api' | 'Script';
export declare const ClientTypeValues: ClientType[];
export interface AuthenticatePacket {
    $type: 'Authenticate';
    clientType: ClientType;
    accessToken: string;
}
export type RpcRequest = ConnectionsListRequest | ConnectionsGetRequest | ConnectionsUpdateRequest | ConnectionsDeleteRequest | ConnectionsAddRequest | ConnectionsGetAttachmentUrlRequest | ConnectionsStartRequest | ConnectionsRestartRequest | ConnectionsStopRequest | ConnectionsTestRequest | LoggingLogRequest | LoggingSubscribeRequest | LoggingUnsubscribeRequest | MessagesSubscribeRequest | MessagesUnsubscribeRequest | ScriptGetIdRequest | ScriptGetNameRequest;
export type RpcResponse = ConnectionsListResponse | ConnectionsGetResponse | ConnectionsUpdateResponse | ConnectionsDeleteResponse | ConnectionsAddResponse | ConnectionsGetAttachmentUrlResponse | ConnectionsStartResponse | ConnectionsRestartResponse | ConnectionsStopResponse | ConnectionsTestResponse | LoggingLogResponse | LoggingSubscribeResponse | LoggingUnsubscribeResponse | MessagesSubscribeResponse | MessagesUnsubscribeResponse | ScriptGetIdResponse | ScriptGetNameResponse;
export interface RequestPacket {
    $type: 'Request';
    requestId: string;
    request: RpcRequest;
}
export interface ResponsePacket {
    $type: 'Response';
    requestId: string;
    result: ResponseResult;
}
export type ResponseResult = SuccessResult | ErrorResult;
export interface SuccessResult {
    $type: 'Success';
    data: RpcResponse;
}
export interface ErrorResult {
    $type: 'Error';
    code: ErrorCode;
    message: string;
    extra: object | null;
}
export interface SubscriptionId {
    id: string;
}
export type Letter = LogLetter | ChatMessageLetter;
export interface MailPacket {
    $type: 'Mail';
    subscriptionId: SubscriptionId;
    letters: Letter[];
}
export type RpcService = 'Logging' | 'Messages' | 'Connections' | 'Script';
export declare const RpcServiceValues: RpcService[];
export interface LogLetter {
    $type: 'Log';
    id: string;
    timestamp: string;
    severity: LogSeverity;
    sourceType: LogSourceType;
    sourceId: string;
    category: string;
    text: string;
}
export interface LogFilter {
    severities: LogSeverity[] | null;
    sourceType: LogSourceType | null;
    sourceId: string | null;
    category: string | null;
}
export interface ChatMessageLetter {
    $type: 'ChatMessage';
    content: ChatMessageDto;
}
export interface ChatMessageFilter {
    protocol: Protocol | null;
    connectionId: string | null;
}
export interface ConnectionTestResult {
    duration: number;
    extra: object | null;
}
export interface ConnectionsListRequest {
    $type: 'Connections/List';
}
export interface ConnectionsListResponse {
    $type: 'Connections/List';
    result: ConnectionDto[];
}
export interface ConnectionsGetRequest {
    $type: 'Connections/Get';
    id: string;
}
export interface ConnectionsGetResponse {
    $type: 'Connections/Get';
    result: ConnectionDto;
}
export interface ConnectionsUpdateRequest {
    $type: 'Connections/Update';
    id: string;
    name: string | null;
    config: ProtocolConfiguration | null;
    autoStart: boolean | null;
}
export interface ConnectionsUpdateResponse {
    $type: 'Connections/Update';
    result: ConnectionDto;
}
export interface ConnectionsDeleteRequest {
    $type: 'Connections/Delete';
    id: string;
}
export interface ConnectionsDeleteResponse {
    $type: 'Connections/Delete';
}
export interface ConnectionsAddRequest {
    $type: 'Connections/Add';
    name: string;
    protocol: Protocol;
    config: ProtocolConfiguration;
}
export interface ConnectionsAddResponse {
    $type: 'Connections/Add';
    result: ConnectionDto;
}
export interface ConnectionsGetAttachmentUrlRequest {
    $type: 'Connections/GetAttachmentUrl';
    id: string;
    attachmentId: string;
}
export interface ConnectionsGetAttachmentUrlResponse {
    $type: 'Connections/GetAttachmentUrl';
    result: string;
}
export interface ConnectionsStartRequest {
    $type: 'Connections/Start';
    id: string;
}
export interface ConnectionsStartResponse {
    $type: 'Connections/Start';
}
export interface ConnectionsRestartRequest {
    $type: 'Connections/Restart';
    id: string;
}
export interface ConnectionsRestartResponse {
    $type: 'Connections/Restart';
}
export interface ConnectionsStopRequest {
    $type: 'Connections/Stop';
    id: string;
}
export interface ConnectionsStopResponse {
    $type: 'Connections/Stop';
}
export interface ConnectionsTestRequest {
    $type: 'Connections/Test';
    protocol: Protocol;
    config: ProtocolConfiguration;
}
export interface ConnectionsTestResponse {
    $type: 'Connections/Test';
    result: ConnectionTestResult;
}
export interface LoggingLogRequest {
    $type: 'Logging/Log';
    severity: LogSeverity;
    message: string;
}
export interface LoggingLogResponse {
    $type: 'Logging/Log';
}
export interface LoggingSubscribeRequest {
    $type: 'Logging/Subscribe';
    filter: LogFilter;
}
export interface LoggingSubscribeResponse {
    $type: 'Logging/Subscribe';
    result: SubscriptionId;
}
export interface LoggingUnsubscribeRequest {
    $type: 'Logging/Unsubscribe';
    subscriptionId: SubscriptionId;
}
export interface LoggingUnsubscribeResponse {
    $type: 'Logging/Unsubscribe';
}
export interface MessagesSubscribeRequest {
    $type: 'Messages/Subscribe';
    filter: ChatMessageFilter;
}
export interface MessagesSubscribeResponse {
    $type: 'Messages/Subscribe';
    result: SubscriptionId;
}
export interface MessagesUnsubscribeRequest {
    $type: 'Messages/Unsubscribe';
    subscriptionId: SubscriptionId;
}
export interface MessagesUnsubscribeResponse {
    $type: 'Messages/Unsubscribe';
}
export interface ScriptGetIdRequest {
    $type: 'Script/GetId';
}
export interface ScriptGetIdResponse {
    $type: 'Script/GetId';
    result: string;
}
export interface ScriptGetNameRequest {
    $type: 'Script/GetName';
}
export interface ScriptGetNameResponse {
    $type: 'Script/GetName';
    result: string;
}
export interface DiscordProtocolConfiguration {
    $type: 'Discord';
    token: string;
    receiveEvents: boolean;
    isPresenceIntentEnabled: boolean;
    isServerMembersIntentEnabled: boolean;
    isMessageContentIntentEnabled: boolean;
    proxyId: string | null;
}
export type ProtocolConfiguration = DiscordProtocolConfiguration | TelegramProtocolConfiguration | TwitchProtocolConfiguration;
export interface TelegramProtocolConfiguration {
    $type: 'Telegram';
    token: string;
    receiveEvents: boolean;
    proxyId: string | null;
}
export type TwitchSubscriptionTopic = 'ChannelCheer' | 'ChannelUpdate' | 'ChannelFollow' | 'ChannelAdBreakBegin' | 'ChannelChatMessage' | 'ChannelSubscribe' | 'ChannelSubscriptionEnd' | 'ChannelSubscriptionGift' | 'ChannelSubscriptionMessage' | 'ChannelRaidTo' | 'ChannelRaidFrom' | 'ChannelBan' | 'ChannelUnban' | 'ChannelModeratorAdd' | 'ChannelModeratorRemove' | 'ChannelChannelPointsCustomRewardAdd' | 'ChannelChannelPointsCustomRewardUpdate' | 'ChannelChannelPointsCustomRewardRemove' | 'ChannelChannelPointsCustomRewardRedemptionAdd' | 'ChannelChannelPointsCustomRewardRedemptionUpdate' | 'ChannelPollBegin' | 'ChannelPollProgress' | 'ChannelPollEnd' | 'ChannelPredictionBegin' | 'ChannelPredictionProgress' | 'ChannelPredictionLock' | 'ChannelPredictionEnd' | 'ChannelSuspiciousUserUpdate' | 'ChannelSuspiciousUserMessage' | 'ChannelVipAdd' | 'ChannelVipRemove' | 'ChannelWarningAcknowledge' | 'ChannelWarningSend' | 'ChannelHypeTrainBegin' | 'ChannelHypeTrainProgress' | 'ChannelHypeTrainEnd' | 'ChannelCharityCampaignDonate' | 'ChannelCharityCampaignStart' | 'ChannelCharityCampaignProgress' | 'ChannelCharityCampaignStop' | 'ChannelShieldModeBegin' | 'ChannelShieldModeEnd' | 'ChannelShoutoutCreate' | 'ChannelShoutoutReceive' | 'ChannelGoalBegin' | 'ChannelGoalProgress' | 'ChannelGoalEnd' | 'StreamOnline' | 'StreamOffline' | 'UserUpdate' | 'UserWhisperMessage';
export declare const TwitchSubscriptionTopicValues: TwitchSubscriptionTopic[];
export type TwitchScope = 'AnalyticsReadExtensions' | 'AnalyticsReadGames' | 'BitsRead' | 'ChannelBot' | 'ChannelEditCommercial' | 'ChannelManageAds' | 'ChannelManageBroadcast' | 'ChannelManageExtensions' | 'ChannelManageGuestStar' | 'ChannelManageModerators' | 'ChannelManagePolls' | 'ChannelManagePredictions' | 'ChannelManageRaids' | 'ChannelManageRedemptions' | 'ChannelManageSchedule' | 'ChannelManageVideos' | 'ChannelManageVips' | 'ChannelModerate' | 'ChannelReadAds' | 'ChannelReadCharity' | 'ChannelReadEditors' | 'ChannelReadGoals' | 'ChannelReadGuestStar' | 'ChannelReadHypeTrain' | 'ChannelReadPolls' | 'ChannelReadPredictions' | 'ChannelReadRedemptions' | 'ChannelReadStreamKey' | 'ChannelReadSubscriptions' | 'ChannelReadVips' | 'ClipsEdit' | 'ModerationRead' | 'ModeratorManageAnnouncements' | 'ModeratorManageAutomod' | 'ModeratorManageAutomodSettings' | 'ModeratorManageBannedUsers' | 'ModeratorManageBlockedTerms' | 'ModeratorManageChatMessages' | 'ModeratorManageChatSettings' | 'ModeratorManageGuestStar' | 'ModeratorManageShieldMode' | 'ModeratorManageShoutouts' | 'ModeratorManageUnbanRequests' | 'ModeratorManageWarnings' | 'ModeratorReadAutomodSettings' | 'ModeratorReadBannedUsers' | 'ModeratorReadBlockedTerms' | 'ModeratorReadChatMessages' | 'ModeratorReadChatSettings' | 'ModeratorReadChatters' | 'ModeratorReadFollowers' | 'ModeratorReadGuestStar' | 'ModeratorReadModerators' | 'ModeratorReadShieldMode' | 'ModeratorReadShoutouts' | 'ModeratorReadSuspiciousUsers' | 'ModeratorReadUnbanRequests' | 'ModeratorReadVips' | 'ModeratorReadWarnings' | 'UserBot' | 'UserEdit' | 'UserEditBroadcast' | 'UserManageBlockedUsers' | 'UserManageChatColor' | 'UserManageWhispers' | 'UserReadBlockedUsers' | 'UserReadBroadcast' | 'UserReadChat' | 'UserReadEmail' | 'UserReadEmotes' | 'UserReadFollows' | 'UserReadModeratedChannels' | 'UserReadSubscriptions' | 'UserReadWhispers' | 'UserWriteChat';
export declare const TwitchScopeValues: TwitchScope[];
export interface TwitchAuth {
    clientId: string;
    me: string;
    accessToken: string;
    refreshToken: string;
    scopes: TwitchScope[];
}
export interface TwitchProtocolChannel {
    name: string;
    eventSubscriptions: TwitchSubscriptionTopic[];
}
export interface TwitchProtocolConfiguration {
    $type: 'Twitch';
    auth: TwitchAuth;
    receiveEvents: boolean;
    channels: TwitchProtocolChannel[];
    proxyId: string | null;
}
export interface AttachmentDto {
    id: string;
    name: string | null;
    contentType: string;
}
export interface ChatterSummaryDto {
    id: string;
    name: string;
}
export interface ChatSummaryDto {
    id: string;
    name: string;
}
export interface ChatMessageDto {
    id: string;
    connectionId: string;
    timestamp: string;
    chat: ChatSummaryDto;
    author: ChatterSummaryDto;
    textContent: string | null;
    attachments: AttachmentDto[];
    isSpecial: boolean;
    isDirect: boolean;
    isMissed: boolean;
}
export type ConnectionStatus = 'NotConnected' | 'Connecting' | 'Connected' | 'Reconnecting' | 'DelayedReconnect' | 'Stopping' | 'Error';
export declare const ConnectionStatusValues: ConnectionStatus[];
export type Protocol = 'Discord' | 'Telegram' | 'Twitch';
export declare const ProtocolValues: Protocol[];
export interface ExtendedConnectionStatus {
    status: ConnectionStatus;
    statusChangeDelay: number;
}
export interface ConnectionDto {
    id: string;
    name: string;
    protocol: Protocol;
    autoStart: boolean;
    config: ProtocolConfiguration;
    extendedStatus: ExtendedConnectionStatus;
}
export interface SystemInfoDto {
    hostname: string;
    operatingSystem: string;
    arch: string;
    dotNetVersion: string;
    currentTime: string;
    uptime: number;
}
export interface NekoInfoDto {
    version: string;
    uptime: number;
}
export interface EnvironmentInfoDto {
    system: SystemInfoDto;
    neko: NekoInfoDto;
}
export interface ActivityStatsItemDto {
    period: string;
    totalMessages: number;
    messagesPerMinute: number;
}
export interface ActivityStatsDto {
    items: ActivityStatsItemDto[];
}
export type ProxyType = 'Http' | 'Https' | 'Socks4' | 'Socks4a' | 'Socks5';
export declare const ProxyTypeValues: ProxyType[];
export interface ProxyDto {
    id: string;
    name: string;
    type: ProxyType;
    hostname: string;
    port: number;
    isAuthRequired: boolean;
    username: string | null;
    password: string | null;
}
export type ScriptStatus = 'Stopped' | 'Starting' | 'Running' | 'Restarting' | 'Stopping' | 'Error';
export declare const ScriptStatusValues: ScriptStatus[];
export type ScriptCode = JsScriptCode;
export interface JsScriptCode {
    $type: 'JavaScript';
    source: string;
}
export interface ScriptDto {
    id: string;
    name: string;
    description: string;
    autoStart: boolean;
    code: ScriptCode;
    status: ScriptStatus;
}
export interface UserDto {
    id: string;
    login: string;
    displayName: string;
}
export type LogSourceType = 'System' | 'Connection' | 'Script';
export declare const LogSourceTypeValues: LogSourceType[];
export type LogSeverity = 'Critical' | 'Error' | 'Warning' | 'Info' | 'Verbose' | 'Debug';
export declare const LogSeverityValues: LogSeverity[];
