import NekoRpc from './internal/rpc/index.js';
declare class NekoRuntime {
    #private;
    rpc: NekoRpc;
    private constructor();
    static create(): Promise<NekoRuntime>;
}
declare const _default: NekoRuntime;
export default _default;
